const { 
    Client, 
    GatewayIntentBits, 
    REST, 
    Routes, 
    SlashCommandBuilder, 
    PermissionFlagsBits, 
    EmbedBuilder 
} = require('discord.js');
const express = require('express');

// --- SISTEM KEEP-ALIVE (Penting untuk Hosting Gratis) ---
const app = express();
app.get('/', (req, res) => {
  res.send('Bot Discord Sedang Berjalan!');
});
app.listen(3000, () => {
  console.log('Server monitoring siap di port 3000.');
});

// --- KONFIGURASI ---
// Menggunakan process.env agar TOKEN aman saat diupload ke GitHub
const TOKEN = 'MTQ2NTI0ODcyNTEwOTU3MTcxMg.GyfKYK.QZNW-B7KlNukozUADvfRHqtTpG10rKFFqh6sXg'; 
const CLIENT_ID = '1465248725109571712';

const client = new Client({ 
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMembers, 
        GatewayIntentBits.GuildMessages
    ] 
});

// --- 1. DEFINISI PERINTAH ---
const commands = [
    new SlashCommandBuilder()
        .setName('server')
        .setDescription('Menampilkan informasi tentang server ini'),

    new SlashCommandBuilder()
        .setName('user')
        .setDescription('Menampilkan informasi tentang pengguna')
        .addUserOption(option => option.setName('target').setDescription('Pilih user yang ingin dilihat')),

    new SlashCommandBuilder()
        .setName('kick')
        .setDescription('Mengeluarkan member dari server')
        .addUserOption(option => option.setName('target').setDescription('Member yang mau di-kick').setRequired(true))
        .addStringOption(option => option.setName('alasan').setDescription('Alasan kick'))
        .setDefaultMemberPermissions(PermissionFlagsBits.KickMembers),

    new SlashCommandBuilder()
        .setName('ban')
        .setDescription('Mencekal member dari server')
        .addUserOption(option => option.setName('target').setDescription('Member yang mau di-ban').setRequired(true))
        .addStringOption(option => option.setName('alasan').setDescription('Alasan ban'))
        .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers),

    new SlashCommandBuilder()
        .setName('clear')
        .setDescription('Menghapus sejumlah pesan')
        .addIntegerOption(option => option.setName('jumlah').setDescription('Jumlah pesan (1-100)').setRequired(true))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),
].map(command => command.toJSON());

// --- 2. REGISTRASI COMMAND ---
const rest = new REST({ version: '10' }).setToken(TOKEN);

(async () => {
    try {
        console.log('Mendaftarkan Slash Commands...');
        await rest.put(Routes.applicationCommands(CLIENT_ID), { body: commands });
        console.log('Semua perintah berhasil terdaftar!');
    } catch (error) {
        console.error('Error registrasi:', error);
    }
})();

// --- 3. LOGIKA EKSEKUSI ---
client.on('ready', () => {
    console.log(`🤖 Bot Online! Masuk sebagai ${client.user.tag}`);
});

client.on('interactionCreate', async interaction => {
    if (!interaction.isChatInputCommand()) return;

    const { commandName, options, guild } = interaction;

    if (commandName === 'server') {
        const embed = new EmbedBuilder()
            .setTitle(`Info Server: ${guild.name}`)
            .setThumbnail(guild.iconURL({ dynamic: true }))
            .setColor('White')
            .addFields(
                { name: 'ID', value: `\`${guild.id}\``, inline: true },
                { name: 'Owner', value: `<@${guild.ownerId}>`, inline: true },
                { name: 'Member', value: `${guild.memberCount}`, inline: true },
                { name: 'Dibuat', value: `<t:${Math.floor(guild.createdTimestamp / 1000)}:D>`, inline: true }
            )
            .setTimestamp();
        return interaction.reply({ embeds: [embed] });
    }

    if (commandName === 'user') {
        const member = options.getMember('target') || interaction.member;
        const embed = new EmbedBuilder()
            .setTitle(`Profil: ${member.user.tag}`)
            .setThumbnail(member.user.displayAvatarURL({ dynamic: true }))
            .setColor('White')
            .addFields(
                { name: 'ID', value: `\`${member.id}\``, inline: true },
                { name: 'Nickname', value: member.nickname || 'Tidak ada', inline: true },
                { name: 'Akun Dibuat', value: `<t:${Math.floor(member.user.createdTimestamp / 1000)}:R>`, inline: false },
                { name: 'Join Server', value: `<t:${Math.floor(member.joinedTimestamp / 1000)}:R>`, inline: false }
            );
        return interaction.reply({ embeds: [embed] });
    }

    if (commandName === 'kick') {
        const target = options.getMember('target');
        const reason = options.getString('alasan') || 'Tanpa alasan';
        if (!target.kickable) return interaction.reply({ content: 'Gagal: Role bot harus lebih tinggi dari target.', ephemeral: true });
        
        await target.kick(reason);
        return interaction.reply({ content: `**${target.user.tag}** dikeluarkan. Alasan: ${reason}` });
    }

    if (commandName === 'ban') {
        const target = options.getMember('target');
        const reason = options.getString('alasan') || 'Tanpa alasan';
        if (!target.bannable) return interaction.reply({ content: 'Gagal: Role bot harus lebih tinggi dari target.', ephemeral: true });

        await target.ban({ reason });
        return interaction.reply({ content: `**${target.user.tag}** telah diblokir. Alasan: ${reason}` });
    }

    if (commandName === 'clear') {
        const amount = options.getInteger('jumlah');
        if (amount < 1 || amount > 100) return interaction.reply({ content: 'Gunakan angka 1-100.', ephemeral: true });

        await interaction.channel.bulkDelete(amount, true);
        return interaction.reply({ content: `Berhasil menghapus ${amount} pesan.`, ephemeral: true });
    }
});

client.login(TOKEN);